package de.funknetz.server;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;

public class Jammer {
	private ComConnect connection;
	private JComboBox chanBox;
	private JComboBox switBox;
	private int chan;
	private int swit;
	private boolean useGui;
	private JTextArea statusFeld;
	private JFrame frame3;
	boolean validation1;
	private JScrollPane scroller;
	
	public void startJam(String kanal, String schalter, String port) {
		if (!useGui)  {
			String[] testStringA = {kanal, schalter, port};
			boolean validation1 = false;
			for (int i = 0; i < 2; i++) {
				try {
					int test = Integer.parseInt(testStringA[i]);
					if ((i == 0 && Integer.parseInt(testStringA[i]) > 0 && Integer.parseInt(testStringA[i]) < 5) | (i == 1 && Integer.parseInt(testStringA[i]) > 0 && Integer.parseInt(testStringA[i]) < 4)) {
						validation1 = true;
					} //endif
				} catch (Exception ex) {
					System.out.println("FEHLER: Bei den eingegebenen Werten handelt es sich nicht um ganzzahlige Werte");
				} //endtry
			} //endfor
			
			if (!validation1) {
				System.out.println("Ungueltiger Kanal- oder ungueltige Schalter-Nummer.");
			} //endif
			
			if (validation1) {
				System.out.println("\nJammer gestartet ...");
				System.out.println("=========================================");
				try {
					ComConnect.portIdent = testStringA[2];
					connection = new ComConnect();
				} catch (Exception ex) {
					System.out.println("FEHLER:\nEs gab Probleme mit der Serialport-API.\n");
					validation1 = false;
				} //endtry
				Object[] tempArray = getJamCommands((Integer.parseInt(testStringA[0])), (Integer.parseInt(testStringA[1])));
				while (validation1) {
					System.out.println(new Date() + ": Sende 'ON' auf Kanal " +  testStringA[0] + ", Schalter: " + testStringA[1]);
					for (int i = 0; i < 2; i++) {
						connection.transmit((int[]) tempArray[0]);
					} //endfor
					try {
						Thread.sleep(1000);
					} catch (Exception ex) {ex.printStackTrace();}
					System.out.println(new Date() + ": Sende 'OFF' auf Kanal " +  testStringA[0] + ", Schalter: " + testStringA[1]);
					for (int i = 0; i < 2; i++) {
						connection.transmit((int[]) tempArray[1]);
					} //endfor
					try {
						Thread.sleep(1000);
					} catch (Exception ex) {
						ex.printStackTrace();
					} //endtry
				} //endwhile
			} //endif
		} else if (useGui) {
			String[] testStringA = {kanal, schalter, port};
			boolean validation1 = false;
			for (int i = 0; i < 2; i++) {
				try {
					int test = Integer.parseInt(testStringA[i]);
					if ((i == 0 && Integer.parseInt(testStringA[i]) > 0 && Integer.parseInt(testStringA[i]) < 5) | (i == 1 && Integer.parseInt(testStringA[i]) > 0 && Integer.parseInt(testStringA[i]) < 4)) {
						validation1 = true;
					} //endif
				} catch (Exception ex) {
					statusFeld.setText(statusFeld.getText() + "FEHLER: Bei den eingegebenen Werten handelt es sich nicht um ganzzahlige Werte\n");
					autoScroll();
				} //endtry
			} //endfor
			
			if (!validation1) {
				statusFeld.setText(statusFeld.getText() + "Ungueltiger Kanal- oder ungueltige Schalter-Nummer.\n");
				autoScroll();
			} //endif
			
			if (validation1) {
				statusFeld.setText(statusFeld.getText() + "Jammer gestartet ...\n");
				autoScroll();
				try {
					ComConnect.portIdent = testStringA[2];
					connection = new ComConnect();
				} catch (Exception ex) {
					statusFeld.setText(statusFeld.getText() + "FEHLER:\nEs gab Probleme mit der Serialport-API.\n");
					autoScroll();
					validation1 = false;
				} //endtry
				Object[] tempArray = getJamCommands((Integer.parseInt(testStringA[0])), (Integer.parseInt(testStringA[1])));
				while (validation1) {
					statusFeld.setText(statusFeld.getText() + new Date() + ":\nSende 'ON' auf Kanal " +  testStringA[0] + ", Schalter: " + testStringA[1] + "\n");
					autoScroll();
					for (int i = 0; i < 2; i++) {
						connection.transmit((int[]) tempArray[0]);
					} //endfor
					try {
						Thread.sleep(1000);
					} catch (Exception ex) {ex.printStackTrace();}
					statusFeld.setText(statusFeld.getText() + new Date() + ":\nSende 'OFF' auf Kanal " +  testStringA[0] + ", Schalter: " + testStringA[1] + "\n");
					autoScroll();
					for (int i = 0; i < 2; i++) {
						connection.transmit((int[]) tempArray[1]);
					} //endfor
					try {
						Thread.sleep(1000);
					} catch (Exception ex) {
						ex.printStackTrace();
					} //endtry
				} //endwhile
			} //endif
		} //endif
	} //endmethod startJam
	
	public Object[] getJamCommands(int kanal, int schalter) {
		int aufrufWert = (kanal-1)*6;
		aufrufWert += (schalter-1)*2;
		
		int[] switchON = FunknetzServer.makeIt(aufrufWert+1);
		int[] switchOFF = FunknetzServer.makeIt(aufrufWert);
		
		Object[] returnA = {switchON, switchOFF};
		return returnA;
	} //endmethod getJamCommands
	
	public void drawGUI() {
		useGui = true;
		frame3 = new JFrame();
		frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JPanel hintergrund = new JPanel();
		hintergrund.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		JPanel zwischenPanel = new JPanel();
		JLabel chanL = new JLabel("Kanal: ");
		JLabel switL = new JLabel("Schalter: ");
		
		chanBox = new JComboBox();
		chanBox.addItemListener(new ComboBox1Listener());
		for (int i = 0; i < 4; i++) {
			chanBox.addItem("" + (i+1));
		} //endfor
		switBox = new JComboBox();
		switBox.addItemListener(new ComboBox2Listener());
		for (int i = 0; i < 3; i++) {
			switBox.addItem("" + (i+1));
		} //endfor
		
		zwischenPanel.add(chanL);
		zwischenPanel.add(chanBox);
		zwischenPanel.add(switL);
		zwischenPanel.add(switBox);
		
		statusFeld = new JTextArea(10,20);
		statusFeld.setEditable(false);
		statusFeld.setLineWrap(true);
		statusFeld.setText("Waehlen Sie den Kanal und Port und\nklicken Sie auf 'Start' um den Jammer zu\nstarten.\n");
		scroller = new JScrollPane(statusFeld);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroller.setBorder(BorderFactory.createEtchedBorder());
		
		JButton zurueckButton = new JButton("Zurueck");
		zurueckButton.addActionListener(new ButtonListener());
		JButton startButton = new JButton("Start");
		startButton.addActionListener(new ButtonListener());
		JButton abbrButton = new JButton("Abbrechen");
		abbrButton.addActionListener(new ButtonListener());
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(zurueckButton);
		buttonPanel.add(abbrButton);
		buttonPanel.add(startButton);
		
		JPanel teilPanel = new JPanel();
		teilPanel.setLayout(new BorderLayout());
		
		teilPanel.add(BorderLayout.NORTH, zwischenPanel);
		teilPanel.add(BorderLayout.CENTER, scroller);
		teilPanel.add(BorderLayout.SOUTH, buttonPanel);
		
		hintergrund.add(teilPanel);
		frame3.add(hintergrund);
		frame3.pack();
		frame3.setVisible(true);
		autoScroll();
		
	} //endmethod drawGUI
	
	public void autoScroll() {
		int max = scroller.getVerticalScrollBar().getMaximum();
		scroller.getVerticalScrollBar().setValue(max);
	}
	
	class JamRun implements Runnable {
		public void run() {
			startJam((chan+""), (swit+""), ComConnect.portIdent);
		} //endmethod run
	} //endclass JamRun
	
	class ComboBox1Listener implements ItemListener {
		public void itemStateChanged(ItemEvent ev) {
			chan = chanBox.getSelectedIndex() + 1;
		} //endmethod itemStateChanged
	} //endclass ComboBox1Listener
	
	class ComboBox2Listener implements ItemListener {
		public void itemStateChanged(ItemEvent ev) {
			swit = switBox.getSelectedIndex() + 1;
		} //endmethod itemStateChanged
	} //endclass ComboBox2Listener
	
	class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (((JButton)e.getSource()).getText().equals("Start")) {
				try {
					Thread t = new Thread(new JamRun());
					t.start();
				} catch (Exception ex) {ex.printStackTrace();}
			} else if (((JButton)e.getSource()).getText().equals("Abbrechen")) {
				validation1 = false;
				connection = null;
			} else {
				frame3.dispose();
			} //endif
		} //endmethod actionPerformed
	} //endclass ButtonListener
} //endclass Jammer