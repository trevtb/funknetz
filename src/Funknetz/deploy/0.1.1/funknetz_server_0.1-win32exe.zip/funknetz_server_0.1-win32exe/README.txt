STARTING THE APPLICATION:

Simply double click the FunknetzServer.exe file.

Other operating systems will follow as soon as someone is willing to give feedback and test stuff for me.
MacOSX support will follow soon(tm) though.
