STARTING THE APPLICATION:

Linux: 	on modern distributions, you should be able to start the .jar by right-clicking it and selecting --> "Start with <java version>". 
	Where <java version> depends on the Java Virtual Machine you have installed. Sometimes it is also possible to start the jar
	by simply double-clicking it.
	If all that doesn't help, you can still start it with the console command "java -jar FunknetzClient.jar" while being in the
	same directory as the jar-file.

Windows: Simply double-clicking the file should do the job. If that doesn't help, use "java -jar FunknetzClient.jar" on the
	 console while being in the same directory as the .jar-file.
	 Alternatively I also provide packages with a windows executable .exe, take a look at the download page.

Other operating systems will follow as soon as someone is willing to give feedback and test stuff for me.
MacOSX support will follow soon(tm) though.
