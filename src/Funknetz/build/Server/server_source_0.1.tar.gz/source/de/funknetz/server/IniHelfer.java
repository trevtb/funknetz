package de.funknetz.server;

import java.io.*;
import java.util.*;

public class IniHelfer {
	String os;
	String auswahl;
	public ArrayList<String> readIni() {
		ArrayList<String> array = null;
		try {
			FileInputStream fis = new FileInputStream("settings.ini");
			ObjectInputStream ois = new ObjectInputStream(fis);
			os = (String) ois.readObject();
			auswahl = (String) ois.readObject();
			ois.close();
			array = new ArrayList<String>();
			array.add(os);
			array.add(auswahl);
		} catch (FileNotFoundException e) {
			makeNewIni();
		} catch (Exception ex) {
			ex.printStackTrace();
		} //endcatch
		return array;
	} //endmethod readIni
	
	public void writeIni(String os, String auswahl) {
		try {
			FileOutputStream fos = new FileOutputStream("settings.ini");
			ObjectOutputStream ois = new ObjectOutputStream(fos);
			ois.writeObject(os);
			ois.writeObject(auswahl);
			ois.close();
		} catch (Exception ex) {ex.printStackTrace();}
	} //endmethod writeIni
		
	public void makeNewIni() {
		os = "unix";
		auswahl = "/dev/ttyS0";
		writeIni(os, auswahl);
	} //endmethod makeNewIni
} //endclass IniHelfer