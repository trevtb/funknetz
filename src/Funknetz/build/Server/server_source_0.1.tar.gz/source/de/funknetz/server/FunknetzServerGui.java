package de.funknetz.server;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;

class FunknetzServerGui {
	private JButton start;
	private JButton stop;
	private JTextArea status;
	private FunknetzServer server;
	private JFrame frame;
	private JTextField portTextF;
	private ArrayList<JCheckBox> checkBoxListe;
	private String os = "";
	private JFrame frame2;
	private String[] portListe;
	private String portString;
	private ArrayList<JRadioButton> radioButtonArray;
	
	public void draw() {
		server = new FunknetzServer();
		frame = new JFrame();
		frame.setTitle("FN Server v0.1");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JMenuBar menubar = new JMenuBar();							// Hier wird die Menueleiste erzeugt
		JMenu menu = new JMenu("Datei");
		JMenuItem settings = new JMenuItem("Einstellungen");
		settings.addActionListener(new SettingsMenuListener());
		menu.add(settings);
		menubar.add(menu);
		JPanel hintergrund = new JPanel();
		hintergrund.setLayout(new BoxLayout(hintergrund, BoxLayout.Y_AXIS));
		hintergrund.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		GridLayout raster = new GridLayout(2,2);
		raster.setVgap(5);
		raster.setHgap(5);
		JPanel buttonBox = new JPanel(raster);
		buttonBox.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));
		JLabel portLabel = new JLabel("Port:");
		buttonBox.add(portLabel);
		portTextF = new JTextField(10);
		portTextF.setText("5000");
		buttonBox.add(portTextF);
		portTextF.requestFocus();
		start = new JButton("Start Server");
		start.addActionListener(new MeinButtonListener());
		stop = new JButton("Stop Server");
		stop.addActionListener(new MeinButtonListener());
		buttonBox.add(start);
		buttonBox.add(stop);
		
		status = new JTextArea(10,22);
		status.setLineWrap(true);
		JScrollPane scroller = new JScrollPane(status);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroller.setBorder(BorderFactory.createEtchedBorder());
		
		hintergrund.add(buttonBox);
		hintergrund.add(scroller);
		
		frame.setJMenuBar(menubar);
		frame.getContentPane().add(hintergrund);
		frame.pack();
		frame.setVisible(true);
	} //endmethod draw
	
	public void drawSettings() {
		
		frame2 = new JFrame("Einstellungen");
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel hauptPanel = new JPanel();
		hauptPanel.setLayout(new BorderLayout());
		
		JPanel hintergrund = new JPanel();
		hintergrund.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		JPanel zwischenPanel = new JPanel();
		TitledBorder title = BorderFactory.createTitledBorder("Serial Port Einstellungen");
		zwischenPanel.setBorder(title);
		
		JPanel southBox = new JPanel();
		southBox.setLayout(new BorderLayout());
		
		JLabel infoLabel = new JLabel("Waehlen Sie Ihr Betriebssystem und dann den Serial Port aus.");
		
		JPanel buttonBox = new JPanel();
		JButton cancelButton = new JButton("Abbrechen");
		cancelButton.addActionListener(new MeinButtonListener());
		JButton okButton = new JButton("Ok");
		okButton.addActionListener(new MeinButtonListener());
		buttonBox.add(cancelButton);
		buttonBox.add(okButton);
		
		southBox.add(BorderLayout.CENTER, buttonBox);
		southBox.add(BorderLayout.NORTH, infoLabel);
		
		checkBoxListe = new ArrayList<JCheckBox>();
		for (int i = 0; i < 4; i++) {
			JCheckBox box = new JCheckBox();
			box.addItemListener(new CheckBoxListener());
			checkBoxListe.add(box);
		} //endfor
		
		JPanel[] panelArray = new JPanel[4];
		for (int i = 0; i < 4; i++) {
			GridLayout raster = new GridLayout(2,1);
			raster.setVgap(5);
			JPanel checkBoxPan = new JPanel(raster);
			panelArray[i] = checkBoxPan;
		} //endfor
		
		ArrayList<JLabel> labelNumberA = new ArrayList<JLabel>();
		for (int i = 0; i < 4; i++) {
			JLabel lab = new JLabel(i+1+"");
			lab.setHorizontalTextPosition(SwingConstants.RIGHT);
			labelNumberA.add(lab);
		} //endfor
			
		
		panelArray[0].add(labelNumberA.get(0));
		panelArray[0].add(labelNumberA.get(2));
		panelArray[1].add(checkBoxListe.get(0));
		panelArray[1].add(checkBoxListe.get(1));
		panelArray[2].add(labelNumberA.get(1));
		panelArray[2].add(labelNumberA.get(3));
		panelArray[3].add(checkBoxListe.get(2));
		panelArray[3].add(checkBoxListe.get(3));
		
		
		radioButtonArray = new ArrayList<JRadioButton>();
		JRadioButton unixRadioButton = new JRadioButton();
		unixRadioButton.addActionListener(new RadioButtonUnixListener());
		JRadioButton winRadioButton = new JRadioButton();
		winRadioButton.addActionListener(new RadioButtonWinListener());
		radioButtonArray.add(unixRadioButton);
		radioButtonArray.add(winRadioButton);
		
		JLabel label1 = new JLabel("Linux/FreeBSD (i686)");
		JLabel label2 = new JLabel("Windows (i386)");
		
		GridLayout raster2 = new GridLayout(2,2);
		raster2.setVgap(5);
		JPanel labelPan = new JPanel(raster2);
		labelPan.add(label1);
		labelPan.add(radioButtonArray.get(0));
		labelPan.add(label2);
		labelPan.add(radioButtonArray.get(1));
		
		zwischenPanel.add(labelPan);
		for (JPanel element : panelArray) {
			zwischenPanel.add(element);
		} //endfor
		
		String[] settings = FunknetzServer.readIni();
		String o = settings[0];
		String au = settings[1];
		for (int i = 0; i < 8; i++) {
			if (portListe[i].equals(au) && o.equals("unix")) {
				checkBoxListe.get(i).setSelected(true);
				radioButtonArray.get(0).setSelected(true);
				os = "unix";
			} else if (portListe[i].equals(au) && o.equals("windows")) {
				checkBoxListe.get(i-4).setSelected(true);
				radioButtonArray.get(1).setSelected(true);
				os = "windows";
			} //endif
		} //endfor
		
		hauptPanel.add(BorderLayout.CENTER, zwischenPanel);
		hauptPanel.add(BorderLayout.SOUTH, southBox);
		
		hintergrund.add(hauptPanel);
		
		frame2.getContentPane().add(hintergrund);
		frame2.pack();
		frame2.setVisible(true);
	} //endmethod drawSettings
		
	public void setStatusText(String s) {
		status.setText(status.getText() + s);
	} //endmethodsetStatusText
	
	public FunknetzServerGui () {
		String[] portis = {"/dev/ttyS0", "/dev/ttyS2", "/dev/ttyS1", "/dev/ttyS3", "COM1", "COM3", "COM2", "COM4"};
		portListe = portis;
		draw();
	} //endkonstruktor FunknetzServerGui
	
	public void zeichneNeu() {
		frame.repaint();
	} //endmethod zeichneNeu
	
	public String getPortTextF() {
		return portTextF.getText();
	} //endmethod getPortTextF
	
	class MeinButtonListener implements ActionListener {
		public void actionPerformed (ActionEvent ev) {
			String command = ev.getActionCommand();
			if (command.equals("Start Server")) {
				server.startListening();
			} else if (command.equals("Stop Server")) {
				server.stopListening();
			} else if (command.equals("Abbrechen")) {
				frame2.dispose();
			} else if (command.equals("Ok")) {
				for (int i = 0; i < checkBoxListe.size(); i++) {
					if (checkBoxListe.get(i).isSelected() && os.equals("unix")) {
						portString = portListe[i];
					} else if (checkBoxListe.get(i).isSelected() && os.equals("windows")) {
						portString = portListe[i+4];
					} //endif
				} //endfor
				ComConnect.portIdent = portString;
				FunknetzServer.writeIni(os, portString);
				frame2.dispose();
			} //endif
		} //endmethod actionPerformed
	} //endclass MeinButtonListener
	
	class RadioButtonUnixListener implements ActionListener {
		public void actionPerformed (ActionEvent ev) {
			radioButtonArray.get(1).setSelected(false);
			os = "unix";
		} //endmethod stateChanged
	} //endclass RadioButtonUnixListener
	
	class RadioButtonWinListener implements ActionListener {
		public void actionPerformed (ActionEvent ev) {
			radioButtonArray.get(0).setSelected(false);
			os = "windows";
		} //endmethod actionPerformed
	} //endclass RadioButtonWinListener
	
	class CheckBoxListener implements ItemListener {
		public void itemStateChanged(ItemEvent e) {
			int status = e.getStateChange();
			if (status == 1) {
				for (JCheckBox element : checkBoxListe) {
					if (element.isSelected() && element != e.getSource()) {
						element.setSelected(false);
					} //endif
				} //endfor
			} //endif
		} //endmethod itemStateChanged
	} //endclass CheckBoxListener
	
	class SettingsMenuListener implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			drawSettings();
		} //endmethod actionPerformed
	} //endclass SettingsMenuListener
	
} //endclass FunknetzServerGui