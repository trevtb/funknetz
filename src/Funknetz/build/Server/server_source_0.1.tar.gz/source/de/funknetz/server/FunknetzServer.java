package de.funknetz.server;

import java.io.*;
import java.net.*;
import java.util.*;

public class FunknetzServer {
	private static int port;
	private static FunknetzServerGui gui;
	private ServerSocket serverSock;
	private boolean isActive;
	private static boolean useGui = true;
	private ComConnect connection;
	private static IniHelfer helfer;
	
	public static void main (String[] args) {
		FunknetzServer.helfer = new IniHelfer();
		String[] portsi = {"/dev/ttyS0", "/dev/ttyS2", "/dev/ttyS1", "/dev/ttyS3", "COM1", "COM3", "COM2", "COM4"};
		ArrayList<String> tempIni = helfer.readIni();
		String tempAus = tempIni.get(1);
		ComConnect.portIdent = tempAus;
		if (args.length == 1 && args[0].equals("--help")) {
			System.out.println("Syntax:\nOhne GUI: 'java FunknetzServer [port]\nMit GUI: 'java FunknetzServer'."); 
		} else if (args.length == 0) {
			gui = new FunknetzServerGui();
		} else if (args.length == 2 && !args[0].equals("--help")) {
			boolean valid = false;
			for (String elem : portsi) {
				if (elem.equals(args[1])) {
					valid = true;
				} //endif
			} //endfor
			
			if (valid) {
				ComConnect.portIdent = args[1];
				useGui = false;
				FunknetzServer server = new FunknetzServer();
				try {
					port = Integer.parseInt(args[0]);
					server.startListening();
				} catch (NumberFormatException ex) {
					System.out.println("Sie haben eine ungueltige Portnummer eingegeben.");
				} //endtry
			} else if (valid == false) {
				System.out.println("Die Serial-Port Nummer ist ungueltig. Richtig waere z.B. fuer Windows COM1 oder fuer Linux /dev/ttyS0");
			} //endif
		} else {
				System.out.println("Falsche Syntax. Benutzen Sie: 'java FunknetzServer [port] [serialport]'. z.B. java FunknetzServer 5000 COM1.");
		} //endif
	} //endmethod main
	
	public class StartListening implements Runnable{
		public void run() {
			try { 
				serverSock = new ServerSocket(port);
				gui.setStatusText("Listening on port: " + port + "\n");
				isActive = true;
			} catch (IllegalArgumentException iae) {
				gui.setStatusText("Ungueltige Portnummer: " + port + ".\n");
			} catch (IOException ex) {
				gui.setStatusText("Der Port " + port + " wird bereits benutzt.\n");
				stopListening();
			} //endtry
			
			if (isActive) {
				try {
					connection = new ComConnect();
					gui.setStatusText("server started ...\n"); 
				} catch (Exception ex) {
					gui.setStatusText("FEHLER: Kann " + ComConnect.portIdent + " nicht oeffnen.\n");
					stopListening();
				} //endtry
				if (isActive) {
					try {
						while (true) {
							Socket s = serverSock.accept();
							ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
							int[] meinArray = (int[]) ois.readObject();
							execute(meinArray);
						} //endwhile
					} catch (Exception ex) {}
				} //endif
			} //endif
		} //endmethod run
	} //endclass StartListening
	
	public void startListening() {
		if (isActive == false) {
			if (useGui) {
				String portText = gui.getPortTextF();
				try {
					port = Integer.parseInt(portText);
				} catch (NumberFormatException ex) {
					gui.setStatusText("Bitte gueltige Portnummer eingeben.\n");
					portText = "";
				} //endtry
				
				if (!portText.equals("")) {
					Thread listenToSock = new Thread(new StartListening());
					listenToSock.start();
				} //endif
			} else {
				System.out.println("\n### Funknetz-Server v0.1 ###");
				System.out.println("=========================================");
				try { 
					serverSock = new ServerSocket(port);
					System.out.println("Listening on port: " + port + "\n");
					isActive = true;
				} catch (IOException ex) {
					System.out.println("Der Port " + port + " wird bereits benutzt.");
				} catch (IllegalArgumentException iae) {
					System.out.println("Ungueltige Portnummer: " + port + ".");
				} //endtry
				if (isActive) {
					System.out.println("Initialisiere ComPort ...");
					try {
						connection = new ComConnect();
					} catch (Exception ex) {
						System.out.println("\nFEHLER: Der ComPort " + ComConnect.portIdent + " konnte nicht geoeffnet werden. Vielleicht existiert er nicht oder wird bereits verwendet.");
						stopListening();
					} //endtry
					if (isActive) {
						try {
							System.out.println("Initialisierung abgeschlossen ...");
							System.out.println("\nserver started ...\n");
							while (true) {
								Socket s = serverSock.accept();
								ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
								int[] meinArray = (int[]) ois.readObject();
								execute(meinArray);
							} //endwhile
						} catch (Exception ex) {}
					} //endif
				} //endif
			} //endif
		} else {
			if (useGui) {
				gui.setStatusText("Der Server ist bereits gestartet");
			} else {
				System.out.println("Der Server ist bereits gestartet");
			} //endif
		} //endif
	} //endmethod startListening
	
	public void stopListening() {
		if (useGui) {
			if (isActive) {
				gui.setStatusText("server stopped ...\nListening on port: " + port + " halted.\n");
			} else {
				gui.setStatusText("Der Server ist bereits angehalten.\n");
			} //endif
		} else {
			System.out.println("server stopped ...\nListening on port: " + port + " halted.\n");
		} //endif
		try {
			serverSock.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} //endtry
		isActive = false;
	} //endmethod stopListening
	
	public int getPort() {
		return port;
	} //endmethod getPort
	
	public void execute(int[] array) {
		if (useGui) {
			String outputString = "";
		
			for (int i = 0; i < array.length; i++) {
				outputString = outputString + (Integer.toHexString(array[i]) + " ");
			} //endfor
			gui.setStatusText((new Date()).toString() + ": \nBefehl erhalten: " + outputString + "\n\n");
		} else {
			String outputString = "";
			
			for (int i = 0; i < array.length; i++) {
				outputString = outputString + (Integer.toHexString(array[i]) + " ");
			} //endfor
			
			System.out.println((new Date()).toString() + ": \nBefehl erhalten: " + outputString + "\n\n");
		} //endif
		connection.transmit(array);
	} //endmethod execute
	
	public static String[] readIni() {
		ArrayList<String> objArray = helfer.readIni();
		String os = (String) objArray.get(0);
		String auswahl = (String) objArray.get(1);
		String[] tempA = {os, auswahl};
		return tempA;
	} //endmethod readIni
	
	public static void writeIni(String a, String b) {
		String os = a;
		String auswahl = b;
		helfer.writeIni(os, auswahl);
	} //endmethod writeIni
	
	public FunknetzServer() {
		isActive = false;
		helfer = new IniHelfer();
	} //endkonstruktor FunknetzServer
	
} //endclass FunknetzServer